import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

// Parse .env.local manually
const envPath = path.resolve(process.cwd(), '.env.local');
const envContent = fs.readFileSync(envPath, 'utf8');
const env: Record<string, string> = {};
envContent.split('\n').forEach(line => {
  if (line && !line.startsWith('#') && line.includes('=')) {
    const [key, ...value] = line.split('=');
    env[key.trim()] = value.join('=').trim();
  }
});

const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase credentials in .env.local');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function makeAdmin() {
  console.log('Fetching users...');
  // Get all users
  const { data: profiles, error: profileError } = await supabase
    .from('user_profiles')
    .select('*');

  if (profileError || !profiles || profiles.length === 0) {
    console.error('Error fetching users or no users found:', profileError);
    return;
  }

  const user = profiles[0]; // Assuming Bipul is the first/only user
  console.log(`Found user: ${user.name} (${user.email})`);

  console.log('Fetching Superadmin role...');
  const { data: roles, error: rolesError } = await supabase
    .from('roles')
    .select('*')
    .eq('name', 'Superadmin')
    .single();

  if (rolesError || !roles) {
    console.error('Error fetching Superadmin role. Did you run seed-roles.sql?', rolesError);
    return;
  }

  console.log('Assigning Superadmin role...');
  // Insert into user_roles
  const { error: insertError } = await supabase
    .from('user_roles')
    .insert({
      user_id: user.id,
      role_id: roles.id,
    });

  if (insertError && insertError.code !== '23505') { // Ignore unique constraint if already assigned
    console.error('Error assigning role:', insertError);
    return;
  }

  // Set is_superadmin in user_profiles
  const { error: updateError } = await supabase
    .from('user_profiles')
    .update({ is_superadmin: true })
    .eq('id', user.id);

  if (updateError) {
    console.error('Error updating user profile:', updateError);
    return;
  }

  console.log('Successfully made user a Superadmin!');
}

makeAdmin();
