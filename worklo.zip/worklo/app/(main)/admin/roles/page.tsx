import { RolesList } from '@/components/admin/roles-list';

export default function RolesPage() {
  return (
    <div className="w-full">
      <RolesList />
    </div>
  );
}
