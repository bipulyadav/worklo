import { Metadata } from 'next';
import { RoleGuard } from '@/components/role-guard';
import { Permission } from '@/lib/permissions';
import { AdminTabs } from '@/components/admin/admin-tabs';

export const metadata: Metadata = {
  title: 'Admin Panel',
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <RoleGuard requireAnyPermission={[Permission.MANAGE_USERS, Permission.MANAGE_USER_ROLES]}>
      <div className="space-y-6">
        <div>
          <h1 className="page-title">Admin Panel</h1>
          <p className="page-subtitle">Manage your organization's users and roles</p>
        </div>
        <AdminTabs />
        <div className="mt-6">
          {children}
        </div>
      </div>
    </RoleGuard>
  );
}
