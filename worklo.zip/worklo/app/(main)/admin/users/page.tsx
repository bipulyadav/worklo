import { UsersTable } from '@/components/admin/users-table';

export default function UsersPage() {
  return (
    <div className="w-full">
      <UsersTable />
    </div>
  );
}
