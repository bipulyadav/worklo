import { NextRequest, NextResponse } from 'next/server';
import { Permission } from '@/lib/permissions';
import { requireAuthAndPermission, handleGuardError } from '@/lib/server-guards';
import { createAdminSupabaseClient } from '@/lib/supabase-server';
import { logger } from '@/lib/debug-logger';

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // Await params since Next.js 15 requires params to be awaited
    const { userId } = await params;
    
    // Require MANAGE_USERS permission
    await requireAuthAndPermission(Permission.MANAGE_USERS, {}, request);

    const adminClient = createAdminSupabaseClient();
    if (!adminClient) {
      return NextResponse.json({ error: 'Supabase not configured' }, { status: 500 });
    }

    logger.info('Deleting user', { action: 'deleteUser', userId });

    // Option 1: Complete deletion from auth.users (cascades to user_profiles)
    const { error: authError } = await adminClient.auth.admin.deleteUser(userId);

    // Note: If using a custom auth provider or just wanting soft-delete, 
    // you would delete/update user_profiles here instead.
    if (authError) {
      // If we couldn't delete from auth (e.g., maybe we don't have admin privileges on auth),
      // fallback to deleting from user_profiles which should cascade or just remove their data
      const { error: profileError } = await adminClient
        .from('user_profiles')
        .delete()
        .eq('id', userId);
        
      if (profileError) {
        logger.error('Failed to delete user profile', { action: 'deleteUser', userId, error: profileError });
        return NextResponse.json({ error: 'Failed to delete user profile' }, { status: 500 });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return handleGuardError(error);
  }
}
