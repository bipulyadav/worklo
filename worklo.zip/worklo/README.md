# Worklo — Full-Stack Assignment

Welcome to the Worklo Full-Stack Assignment!

Worklo is a PSA (Professional Services Automation) platform for managing projects, tasks, time tracking, and client relationships. In this exercise you'll extend the existing codebase by building a real feature end-to-end — touching the database, backend API, and frontend UI.   

Focus on quality over completeness. Submit what you have when time is up.

If you have any questions, feel free to reach out — we're happy to clarify anything.

## Time Consideration

This assignment is scoped for **3–4 hours**. If you hit that limit, submit what you have and use `README.md` to describe what you'd finish next.

---    

## Getting Started

You'll need **Node.js 18+** and a free [Supabase](https://supabase.com) project.

```bash  
# 1. Fork this repo and clone your fork
npm install

# 2. Set up environment variables
cp .env.local.template .env.local
# Fill in your Supabase URL and keys

# 3. Run the database schema
# → Supabase dashboard → SQL Editor → paste and run supabase/schema.sql

# 4. Start the dev server
npm run dev   # Next.js on http://localhost:3000
```

---

## Task Overview

Build an **Admin panel** with a "Users" tab and a "Roles" tab so administrators can view, search, and manage the people and roles in their organization.

- Set up the "Users" and "Roles" tab structure under `/admin`
- Add a users table that displays each user's name, email, avatar, and assigned role(s)
- Add support for filtering the users table via a "Search" input field
- Add support for removing a user from the organization via the "more" icon button dropdown menu
- Add support for viewing all roles with their name, department, hierarchy level, and member count in the "Roles" tab
- Add support for renaming a role inline in the "Roles" tab
- [Bonus] Add cursor-based pagination to the users table

---

## How We Evaluate

- **Full-stack integration** — data flows correctly end-to-end
- **Backend awareness** — correct use of existing auth, error handling, and API patterns
- **Frontend quality** — component structure, loading/error states, UX polish
- **Code quality** — readable, typed, consistent with the existing codebase
- **README.md** — clear reasoning about decisions and trade-offs

---

## Submission Guidelines

Don't open a PR to this repo. Share your **fork URL**.

---

## My Submission

### How to run the project

1. **Install dependencies:**
   ```bash
   npm install
   ```
2. **Environment Variables:**
   Copy `.env.local.template` to `.env.local`:
   ```bash
   cp .env.local.template .env.local
   ```
   Fill in your Supabase URL and keys.
3. **Database Schema:**
   Run the SQL provided in `supabase/schema.sql` on your Supabase dashboard.
4. **Run the server:**
   ```bash
   npm run dev
   ```
5. **Access the Admin Panel:**
   Navigate to `http://localhost:3000/admin` to see the Users and Roles tabs.

### What I've Implemented

- **Admin Layout:** Created a responsive layout for the admin section using `RoleGuard` to restrict access to users with `MANAGE_USERS` or `MANAGE_USER_ROLES` permissions.
- **Users Tab:** 
  - Created a robust table to display users, their avatars, email, and assigned roles.
  - Implemented client-side search filtering by name and email.
  - Added a dropdown menu on each row to remove users from the organization, integrating with a new `DELETE /api/users/[userId]` endpoint.
  - **Bonus:** Implemented true cursor-based pagination (using the `id` field) on the server side (`GET /api/users`) and integrated a "Load More" functionality on the client to fetch data efficiently.
- **Roles Tab:**
  - Designed a table displaying roles, their departments, hierarchy levels, and member counts.
  - Added inline renaming functionality, allowing admins to edit a role's name directly from the table and save it using the existing `PATCH /api/roles/[roleId]` endpoint.

### What I'd improve or do differently if I had more time

1. **Optimistic UI Updates:** For deleting users or renaming roles, implement optimistic UI updates using SWR to provide instant feedback before the server responds.
2. **Server Actions:** Migrate the REST API endpoints to Next.js Server Actions for a more seamless and type-safe data mutation flow, reducing client-side fetching complexity.
3. **Role Assignment:** Add the ability to assign and manage a user's roles directly from the Users table using a multi-select dropdown.
4. **Advanced Filtering & Sorting:** Add table sorting capabilities (e.g., sorting by name, hierarchy level, or member count) and advanced filters for departments and roles.
5. **Testing:** Write unit tests for the React components and integration tests for the API routes using Jest or Vitest to ensure reliability.
