'use client';

import { useState, useRef, useEffect } from 'react';
import useSWR from 'swr';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Loader2, Pencil, Check, X } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';

interface Role {
  id: string;
  name: string;
  department_name: string | null;
  hierarchy_level: number;
  user_count: number;
}

export function RolesList() {
  const { data, error, isLoading, mutate } = useSWR('/api/roles', async (url) => {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch roles');
    return res.json();
  });

  const roles: Role[] = data?.roles || [];

  const [editingRoleId, setEditingRoleId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingRoleId && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingRoleId]);

  const startEdit = (role: Role) => {
    setEditingRoleId(role.id);
    setEditName(role.name);
  };

  const cancelEdit = () => {
    setEditingRoleId(null);
    setEditName('');
  };

  const saveRole = async (roleId: string) => {
    if (!editName.trim()) {
      toast.error('Role name cannot be empty');
      return;
    }
    
    setIsSaving(true);
    try {
      const res = await fetch(`/api/roles/${roleId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editName.trim() }),
      });
      
      if (!res.ok) throw new Error('Failed to update role');
      
      toast.success('Role renamed successfully');
      
      // Update local cache
      mutate((currentData: any) => {
        if (!currentData) return currentData;
        return {
          ...currentData,
          roles: currentData.roles.map((r: Role) => 
            r.id === roleId ? { ...r, name: editName.trim() } : r
          )
        };
      }, false);
      
      setEditingRoleId(null);
    } catch (err) {
      toast.error('Could not rename role');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-md border shadow-sm bg-card text-card-foreground">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Role Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Hierarchy Level</TableHead>
              <TableHead>Members</TableHead>
              <TableHead className="w-[100px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
                </TableCell>
              </TableRow>
            ) : roles.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                  No roles found.
                </TableCell>
              </TableRow>
            ) : (
              roles.map((role) => (
                <TableRow key={role.id}>
                  <TableCell className="font-medium">
                    {editingRoleId === role.id ? (
                      <div className="flex items-center gap-2">
                        <Input
                          ref={inputRef}
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') saveRole(role.id);
                            if (e.key === 'Escape') cancelEdit();
                          }}
                          className="h-8 w-full max-w-[200px]"
                          disabled={isSaving}
                        />
                      </div>
                    ) : (
                      <span className="flex items-center gap-2">
                        {role.name}
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {role.department_name || 'No Department'}
                  </TableCell>
                  <TableCell>Level {role.hierarchy_level}</TableCell>
                  <TableCell>{role.user_count}</TableCell>
                  <TableCell>
                    {editingRoleId === role.id ? (
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-green-600 hover:text-green-700 hover:bg-green-100/50"
                          onClick={() => saveRole(role.id)}
                          disabled={isSaving}
                        >
                          {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-muted-foreground"
                          onClick={cancelEdit}
                          disabled={isSaving}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => startEdit(role)}
                      >
                        <Pencil className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
