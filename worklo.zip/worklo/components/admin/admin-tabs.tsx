'use client';

import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useRouter, usePathname } from 'next/navigation';

export function AdminTabs() {
  const router = useRouter();
  const pathname = usePathname();

  const currentTab = pathname.includes('/admin/roles') ? 'roles' : 'users';

  return (
    <Tabs value={currentTab} onValueChange={(val) => router.push(`/admin/${val}`)} className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="users">Users</TabsTrigger>
        <TabsTrigger value="roles">Roles</TabsTrigger>
      </TabsList>
    </Tabs>
  );
}
